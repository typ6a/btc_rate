<?php $__env->startSection('title', 'View all records'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h2> BTC rate </h2>
            </div>
            <?php if($records->isEmpty()): ?>
                <p> There is no records.</p>
            <?php else: ?>
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
                <table class="table">
                    <thead>
                    <tr>
                        <th>Time</th>
                        <th>USD</th>
                        <th>EUR</th>
                        <th>GBP</th>
                        <th>Provider</th>
                        <th>Record ID</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo $record->updated; ?></td>
                            <td><?php echo number_format($record->usd, 2, '.', ''); ?></td>
                            <td><?php echo number_format($record->eur, 2, '.', ''); ?></td>
                            <td><?php echo number_format($record->gbp, 2, '.', ''); ?></td>
                            <td><?php echo $record->provider; ?></td>
                            <td><?php echo $record->id; ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                    <?php echo e($records->links()); ?>

            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>