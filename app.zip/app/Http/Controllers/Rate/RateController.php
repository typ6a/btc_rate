<?php

namespace App\Http\Controllers\Rate;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Models\Record;

class RateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $records = Record::paginate(5);
        // pre($records,1);
        return view('records.index', compact('records'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        //
    }

    public function saveData()
    {

    }

    public function getBlockchainData()
    {   
        $json = file_get_contents(env('BTC_RATE_BLOCKCHAIN'));
        $row = json_decode($json,true);
// pre(round(12.3,2,3),1);
        $record = new Record(array(
            'usd' => round($row['USD']['buy'], 2),
            'gbp' => round($row['GBP']['buy'], 2),
            'eur' => round($row['EUR']['buy'], 2),
            'updated' => date("Y-m-d H:i:s"),
            'provider' => 'BLOCKCHAIN'
        ));
        $record->save();
        // return redirect('/records')->with('status', 'Last rate data has been got at ' . $record['updated']);
    }

    public function getCoindeskData()
    {   
        $json = file_get_contents(env('BTC_RATE_COINDESK'));
        $row = json_decode($json,true);
        $record = new Record(array(
            'usd' => round($row['bpi']['USD']['rate_float'], 2),
            'gbp' => round($row['bpi']['GBP']['rate_float'], 2),
            'eur' => round($row['bpi']['EUR']['rate_float'], 2),
            'updated' => date("Y-m-d H:i:s"),
            'provider' => 'COINDESK'
        ));
        $record->save();
        
        // return redirect('/records')->with('status', 'Last rate data has been got at ' . $record['updated']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
