<?php
require_once 'public/index.php';